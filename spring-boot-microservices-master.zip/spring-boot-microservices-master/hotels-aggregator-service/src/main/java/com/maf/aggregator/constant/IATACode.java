package com.maf.aggregator.constant;

public enum IATACode {
	AUH,AUJ,AUE;

}

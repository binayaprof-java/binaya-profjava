package com.maf.crazyhotel.domain.model;

public enum IATACode {

	AUH,AUJ,AUE;

}

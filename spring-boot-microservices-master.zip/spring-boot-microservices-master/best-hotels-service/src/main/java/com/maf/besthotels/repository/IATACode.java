package com.maf.besthotels.repository;

public enum IATACode {
	AUH,AUJ,AUE;

}

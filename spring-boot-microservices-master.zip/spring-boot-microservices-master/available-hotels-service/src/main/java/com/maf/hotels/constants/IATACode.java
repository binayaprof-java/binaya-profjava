package com.maf.hotels.constants;

public enum IATACode {
	AUH,AUJ,AUE;
}

package com.maf.hotels.constants;

public class ResponseStatus {

	public final static String RESPONSE_STATUS_SUCCESS = "Success";
	public final static String RESPONSE_STATUS_FAILED = "Failed";
}
